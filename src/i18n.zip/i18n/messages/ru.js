import LOCALES from '../local';

const ru = {
  [LOCALES.RUSSIAN]: {
    title: "История javascript"
  }
}

export default ru