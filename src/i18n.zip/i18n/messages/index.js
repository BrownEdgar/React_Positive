import am from './am'
import ru from './ru'
import en from './en';

export default {
  ...am,
  ...ru,
  ...en,
}