import LOCALES from '../local';

const en = {
  [LOCALES.ENGLISH]: {
    title: "History of javascript"
  }
}

export default en