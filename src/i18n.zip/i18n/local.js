const LOCALES = {
  ENGLISH: 'en-us',
  RUSSIAN: 'ru-ru',
  ARMENIAN: 'am-hy'
}
export default LOCALES;

