import LOCALES from '../local';

const am = {
  [LOCALES.ARMENIAN]: {
    title: "javascript - ի պատմությունը"
  }
}

export default am